package cifradotextoapp;

import javax.swing.*;
import java.awt.*;

public class VentanaCifrado extends JFrame {

    private final JTextArea entrada;
    private final JTextArea salida;
    private final JTextField campoClave;
    private final JComboBox<String> comboMetodo;

    public VentanaCifrado() {
        setTitle("Cifrado de Texto - By Tu Bro 😎");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel();
        comboMetodo = new JComboBox<>(new String[]{"César", "Sustitución", "Por Clave"});
        campoClave = new JTextField(10);
        panelSuperior.add(new JLabel("Método:"));
        panelSuperior.add(comboMetodo);
        panelSuperior.add(new JLabel("Clave:"));
        panelSuperior.add(campoClave);

        JPanel panelCentro = new JPanel(new GridLayout(2, 1));
        entrada = new JTextArea("Escribe aquí tu texto...");
        salida = new JTextArea();
        salida.setEditable(false);
        panelCentro.add(new JScrollPane(entrada));
        panelCentro.add(new JScrollPane(salida));

        JPanel panelBotones = new JPanel();
        JButton btnCifrar = new JButton("Cifrar");
        JButton btnDescifrar = new JButton("Descifrar");
        panelBotones.add(btnCifrar);
        panelBotones.add(btnDescifrar);

        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        btnCifrar.addActionListener(e -> procesar(true));
        btnDescifrar.addActionListener(e -> procesar(false));
    }

    private void procesar(boolean cifrar) {
        String texto = entrada.getText();
        String clave = campoClave.getText();
        String metodo = (String) comboMetodo.getSelectedItem();
        String resultado = "";

        switch (metodo) {
            case "César" -> {
                int desp = clave.isEmpty() ? 3 : Integer.parseInt(clave);
                resultado = cifrar ? Cifrador.cifradoCesar(texto, desp)
                        : Cifrador.descifradoCesar(texto, desp);
            }

            case "Sustitución" -> resultado = cifrar ? Cifrador.cifradoSustitucion(texto)
                                   : Cifrador.descifradoSustitucion(texto);

            case "Por Clave" -> resultado = cifrar ? Cifrador.cifradoPorClave(texto, clave)
                                   : Cifrador.descifradoPorClave(texto, clave);
        }
        salida.setText(resultado);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCifrado().setVisible(true));
    }
}
