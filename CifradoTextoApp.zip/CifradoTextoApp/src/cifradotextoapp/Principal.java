package cifradotextoapp;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Cifrado César");
            System.out.println("2. Cifrado por Sustitución");
            System.out.println("3. Cifrado por Clave");
            System.out.println("4. Abrir interfaz gráfica");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingresa texto: ");
                    String textoCesar = sc.nextLine();
                    System.out.print("Desplazamiento: ");
                    int desp = sc.nextInt();
                    sc.nextLine();
                    String cifradoC = Cifrador.cifradoCesar(textoCesar, desp);
                    System.out.println("Texto cifrado: " + cifradoC);
                    System.out.println("Texto descifrado: " + Cifrador.descifradoCesar(cifradoC, desp));
                    break;

                case 2:
                    System.out.print("Ingresa texto: ");
                    String textoS = sc.nextLine();
                    String cifradoS = Cifrador.cifradoSustitucion(textoS);
                    System.out.println("Texto cifrado: " + cifradoS);
                    System.out.println("Texto descifrado: " + Cifrador.descifradoSustitucion(cifradoS));
                    break;

                case 3:
                    System.out.print("Ingresa texto: ");
                    String textoClave = sc.nextLine();
                    System.out.print("Ingresa clave: ");
                    String clave = sc.nextLine();
                    String cifradoClave = Cifrador.cifradoPorClave(textoClave, clave);
                    System.out.println("Texto cifrado: " + cifradoClave);
                    System.out.println("Texto descifrado: " + Cifrador.descifradoPorClave(cifradoClave, clave));
                    break;

                case 4:
                    VentanaCifrado.main(null);
                    break;

                case 0:
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción inválida, intenta de nuevo.");
            }
        } while (opcion != 0);
    }
}
