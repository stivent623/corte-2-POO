package cifradotextoapp;

public class Cifrador {

    // ==================== CIFRADO CÉSAR ====================
    public static String cifradoCesar(String texto, int desplazamiento) {
        String resultado = "";
        texto = texto.toUpperCase();

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);

            if (c >= 'A' && c <= 'Z') {
                c = (char) ((c - 'A' + desplazamiento) % 26 + 'A');
            }
            resultado += c;
        }
        return resultado;
    }

    public static String descifradoCesar(String texto, int desplazamiento) {
        return cifradoCesar(texto, 26 - desplazamiento);
    }

    // ==================== CIFRADO POR SUSTITUCIÓN ====================
    public static String cifradoSustitucion(String texto) {
        String abecedario = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String clave =       "QWERTYUIOPASDFGHJKLZXCVBNM";
        texto = texto.toUpperCase();
        String resultado = "";

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            int pos = abecedario.indexOf(c);
            if (pos != -1) {
                resultado += clave.charAt(pos);
            } else {
                resultado += c;
            }
        }
        return resultado;
    }

    public static String descifradoSustitucion(String texto) {
        String abecedario = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String clave =       "QWERTYUIOPASDFGHJKLZXCVBNM";
        texto = texto.toUpperCase();
        String resultado = "";

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            int pos = clave.indexOf(c);
            if (pos != -1) {
                resultado += abecedario.charAt(pos);
            } else {
                resultado += c;
            }
        }
        return resultado;
    }

    // ==================== CIFRADO POR CLAVE SIMPLE ====================
    public static String cifradoPorClave(String texto, String clave) {
        String resultado = "";
        for (int i = 0; i < texto.length(); i++) {
            resultado += (char) (texto.charAt(i) ^ clave.charAt(i % clave.length()));
        }
        return resultado;
    }

    public static String descifradoPorClave(String texto, String clave) {
        return cifradoPorClave(texto, clave); // XOR es reversible
    }
}
